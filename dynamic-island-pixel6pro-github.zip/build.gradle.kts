// Top-level build file for Dynamic Island for Google Pixel 6 Pro
plugins {
    id("com.android.application") version "8.2.2" apply false
    id("org.jetbrains.kotlin.android") version "1.9.22" apply false
}
