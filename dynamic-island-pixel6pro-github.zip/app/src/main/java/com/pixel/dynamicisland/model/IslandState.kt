package com.pixel.dynamicisland.model

/**
 * Visual presentation mode of the Dynamic Island.
 */
enum class IslandDisplayMode {
    COMPACT,      // Minimal pill around camera cutout
    EXPANDED,     // Expanded alert (notification snippet, charging, volume)
    INTERACTIVE,  // Full detailed interactive widget (music controls, timer controls)
    DISMISSED     // Hidden / minimal punch-hole mask
}

/**
 * State object observed by the Jetpack Compose overlay window.
 */
data class IslandState(
    val displayMode: IslandDisplayMode = IslandDisplayMode.COMPACT,
    val primaryActivity: IslandActivity = IslandActivity.Idle,
    val secondaryActivity: IslandActivity? = null,
    val isEnabled: Boolean = true,
    val cutoutXOffset: Int = 0,
    val cutoutYOffset: Int = 0,
    val basePillWidthDp: Int = 110,
    val basePillHeightDp: Int = 34
)
