package com.pixel.dynamicisland.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pixel.dynamicisland.model.SettingsState
import com.pixel.dynamicisland.ui.theme.DarkCharcoal
import com.pixel.dynamicisland.ui.theme.PixelCyan
import com.pixel.dynamicisland.ui.theme.PureBlack
import com.pixel.dynamicisland.ui.theme.PureWhite
import com.pixel.dynamicisland.ui.theme.SurfaceDark
import com.pixel.dynamicisland.ui.theme.TextSecondary

@Composable
fun CalibrationScreen(
    currentSettings: SettingsState,
    onSaveCalibration: (xOffset: Int, yOffset: Int, widthDp: Int, heightDp: Int) -> Unit,
    onBack: () -> Unit
) {
    var xOffset by remember { mutableFloatStateOf(currentSettings.cameraCutoutXOffset.toFloat()) }
    var yOffset by remember { mutableFloatStateOf(currentSettings.cameraCutoutYOffset.toFloat()) }
    var widthDp by remember { mutableFloatStateOf(currentSettings.pillBaseWidthDp.toFloat()) }
    var heightDp by remember { mutableFloatStateOf(currentSettings.pillBaseHeightDp.toFloat()) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top App Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 16.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(onClick = onBack) {
                Icon(Icons.Default.ArrowBack, contentDescription = "Back", tint = PureWhite)
            }
            Text(
                text = "Pixel 6 Pro Camera Calibration",
                color = PureWhite,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
        }

        // Live Alignment Preview Mockup
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp),
            colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
            shape = RoundedCornerShape(20.dp)
        ) {
            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.TopCenter
            ) {
                // Mockup of front camera lens
                Box(
                    modifier = Modifier
                        .padding(top = 22.dp)
                        .size(16.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF0D47A1))
                        .border(1.5.dp, Color(0xFF00E5FF), CircleShape)
                )

                // Simulated Pill overlay
                Box(
                    modifier = Modifier
                        .padding(top = (22 + yOffset).dp)
                        .width(widthDp.dp)
                        .height(heightDp.dp)
                        .clip(RoundedCornerShape((heightDp / 2).dp))
                        .background(Color.Black.copy(alpha = 0.85f))
                        .border(1.dp, PixelCyan.copy(alpha = 0.7f), RoundedCornerShape((heightDp / 2).dp))
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Calibration Sliders
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .background(SurfaceDark, RoundedCornerShape(16.dp))
                .padding(16.dp)
        ) {
            Text(
                text = "Vertical Offset (Y): ${yOffset.toInt()} dp",
                color = PureWhite,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
            Slider(
                value = yOffset,
                onValueChange = { yOffset = it },
                valueRange = -30f..50f,
                colors = SliderDefaults.colors(thumbColor = PixelCyan, activeTrackColor = PixelCyan)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Horizontal Offset (X): ${xOffset.toInt()} dp",
                color = PureWhite,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
            Slider(
                value = xOffset,
                onValueChange = { xOffset = it },
                valueRange = -40f..40f,
                colors = SliderDefaults.colors(thumbColor = PixelCyan, activeTrackColor = PixelCyan)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Base Pill Width: ${widthDp.toInt()} dp",
                color = PureWhite,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
            Slider(
                value = widthDp,
                onValueChange = { widthDp = it },
                valueRange = 80f..180f,
                colors = SliderDefaults.colors(thumbColor = PixelCyan, activeTrackColor = PixelCyan)
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = "Base Pill Height: ${heightDp.toInt()} dp",
                color = PureWhite,
                fontSize = 13.sp,
                fontWeight = FontWeight.Medium
            )
            Slider(
                value = heightDp,
                onValueChange = { heightDp = it },
                valueRange = 26f..52f,
                colors = SliderDefaults.colors(thumbColor = PixelCyan, activeTrackColor = PixelCyan)
            )
        }

        Spacer(modifier = Modifier.weight(1f))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Button(
                onClick = {
                    xOffset = 0f
                    yOffset = 0f
                    widthDp = 110f
                    heightDp = 34f
                },
                modifier = Modifier.weight(1f),
                colors = ButtonDefaults.buttonColors(containerColor = DarkCharcoal),
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(Icons.Default.Refresh, contentDescription = null, tint = TextSecondary)
                Spacer(modifier = Modifier.width(6.dp))
                Text("Reset", color = TextSecondary)
            }

            Button(
                onClick = {
                    onSaveCalibration(xOffset.toInt(), yOffset.toInt(), widthDp.toInt(), heightDp.toInt())
                    onBack()
                },
                modifier = Modifier.weight(1.5f),
                colors = ButtonDefaults.buttonColors(containerColor = PixelCyan),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("Save Calibration", color = PureBlack, fontWeight = FontWeight.Bold)
            }
        }
    }
}
