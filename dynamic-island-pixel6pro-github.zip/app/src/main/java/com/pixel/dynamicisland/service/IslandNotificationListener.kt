package com.pixel.dynamicisland.service

import android.app.Notification
import android.content.ComponentName
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.media.session.MediaSessionManager
import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.util.Log
import com.pixel.dynamicisland.manager.IslandStateManager
import com.pixel.dynamicisland.manager.SettingsRepository
import com.pixel.dynamicisland.media.MediaSessionHelper
import com.pixel.dynamicisland.model.IslandActivity

class IslandNotificationListener : NotificationListenerService() {

    private lateinit var settingsRepo: SettingsRepository
    private lateinit var mediaHelper: MediaSessionHelper
    private var sessionManager: MediaSessionManager? = null

    private val sessionsChangedListener = MediaSessionManager.OnActiveSessionsChangedListener { controllers ->
        mediaHelper.updateActiveControllers(controllers)
    }

    override fun onCreate() {
        super.onCreate()
        settingsRepo = SettingsRepository.getInstance(this)
        mediaHelper = MediaSessionHelper.getInstance(this)
        sessionManager = getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
    }

    override fun onListenerConnected() {
        super.onListenerConnected()
        try {
            val componentName = ComponentName(this, IslandNotificationListener::class.java)
            sessionManager?.addOnActiveSessionsChangedListener(sessionsChangedListener, componentName)
            val controllers = sessionManager?.getActiveSessions(componentName)
            mediaHelper.updateActiveControllers(controllers)
        } catch (e: SecurityException) {
            Log.e("IslandNotifListener", "SecurityException connecting active sessions: ${e.message}")
        }
    }

    override fun onListenerDisconnected() {
        super.onListenerDisconnected()
        try {
            sessionManager?.removeOnActiveSessionsChangedListener(sessionsChangedListener)
        } catch (e: Exception) {
            Log.e("IslandNotifListener", "Error removing listener: ${e.message}")
        }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val settings = settingsRepo.settings.value
        if (!settings.isIslandEnabled || !settings.enableNotifications) return

        val pkg = sbn.packageName
        // Ignore self notifications and persistent foreground services from Android system
        if (pkg == packageName) return
        if (pkg == "android" || pkg == "com.android.systemui") {
            if (sbn.isOngoing) return
        }

        val notification = sbn.notification ?: return

        // If it's a media style notification, refresh media sessions
        if (notification.extras.containsKey(Notification.EXTRA_MEDIA_SESSION)) {
            val componentName = ComponentName(this, IslandNotificationListener::class.java)
            val controllers = sessionManager?.getActiveSessions(componentName)
            mediaHelper.updateActiveControllers(controllers)
            return
        }

        val extras = notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_TITLE_BIG)?.toString()
            ?: ""
        val text = extras.getCharSequence(Notification.EXTRA_TEXT)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_BIG_TEXT)?.toString()
            ?: extras.getCharSequence(Notification.EXTRA_SUB_TEXT)?.toString()
            ?: ""

        if (title.isBlank() && text.isBlank()) return

        val pm = packageManager
        val appName = try {
            val appInfo = pm.getApplicationInfo(pkg, 0)
            pm.getApplicationLabel(appInfo).toString()
        } catch (e: Exception) {
            pkg
        }

        val appIconBitmap = try {
            drawableToBitmap(pm.getApplicationIcon(pkg))
        } catch (e: Exception) {
            null
        }

        val notifActivity = IslandActivity.AppNotification(
            id = "${sbn.packageName}_${sbn.id}",
            packageName = pkg,
            appName = appName,
            title = title,
            text = text,
            appIcon = appIconBitmap,
            smallIcon = notification.smallIcon
        )

        IslandStateManager.instance.postActivity(IslandStateManager.KEY_NOTIFICATION, notifActivity)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        if (sbn == null) return
        val current = IslandStateManager.instance.islandState.value.primaryActivity
        if (current is IslandActivity.AppNotification && current.id == "${sbn.packageName}_${sbn.id}") {
            IslandStateManager.instance.removeActivity(IslandStateManager.KEY_NOTIFICATION)
        }
    }

    private fun drawableToBitmap(drawable: Drawable): Bitmap {
        if (drawable is BitmapDrawable && drawable.bitmap != null) {
            return drawable.bitmap
        }
        val width = if (drawable.intrinsicWidth > 0) drawable.intrinsicWidth else 96
        val height = if (drawable.intrinsicHeight > 0) drawable.intrinsicHeight else 96
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        drawable.setBounds(0, 0, canvas.width, canvas.height)
        drawable.draw(canvas)
        return bitmap
    }
}
