package com.pixel.dynamicisland.ui.island

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pixel.dynamicisland.model.IslandActivity
import com.pixel.dynamicisland.ui.theme.ChargingAmber
import com.pixel.dynamicisland.ui.theme.PixelCyan
import com.pixel.dynamicisland.ui.theme.PureWhite
import com.pixel.dynamicisland.ui.theme.SpotifyGreen

@Composable
fun CompactIslandView(
    activity: IslandActivity,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // Left accessory (Leading)
        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.Start,
            verticalAlignment = Alignment.CenterVertically
        ) {
            when (activity) {
                is IslandActivity.Media -> {
                    if (activity.albumArtwork != null) {
                        Image(
                            bitmap = activity.albumArtwork.asImageBitmap(),
                            contentDescription = "Album Art",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .size(20.dp)
                                .clip(RoundedCornerShape(6.dp))
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = "Music",
                            tint = SpotifyGreen,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                is IslandActivity.AppNotification -> {
                    if (activity.appIcon != null) {
                        Image(
                            bitmap = activity.appIcon.asImageBitmap(),
                            contentDescription = activity.appName,
                            modifier = Modifier
                                .size(20.dp)
                                .clip(CircleShape)
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.Notifications,
                            contentDescription = "Notification",
                            tint = PixelCyan,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
                is IslandActivity.Charging -> {
                    Icon(
                        imageVector = Icons.Default.Bolt,
                        contentDescription = "Charging",
                        tint = ChargingAmber,
                        modifier = Modifier.size(18.dp)
                    )
                }
                is IslandActivity.PhoneCall -> {
                    Icon(
                        imageVector = Icons.Default.Call,
                        contentDescription = "Call",
                        tint = Color(0xFF4CAF50),
                        modifier = Modifier.size(16.dp)
                    )
                }
                is IslandActivity.Timer -> {
                    Icon(
                        imageVector = Icons.Default.Timer,
                        contentDescription = "Timer",
                        tint = Color(0xFFFF9800),
                        modifier = Modifier.size(16.dp)
                    )
                }
                is IslandActivity.BluetoothDevice -> {
                    Icon(
                        imageVector = Icons.Default.Headphones,
                        contentDescription = "Bluetooth",
                        tint = PixelCyan,
                        modifier = Modifier.size(16.dp)
                    )
                }
                is IslandActivity.Volume -> {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = "Volume",
                        tint = PureWhite,
                        modifier = Modifier.size(16.dp)
                    )
                }
                is IslandActivity.Idle -> {
                    // Small aesthetic breathing indicator dot
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF222222))
                    )
                }
            }
        }

        // Center space (Where the Pixel 6 Pro front camera punch-hole is located)
        Spacer(modifier = Modifier.width(36.dp))

        // Right accessory (Trailing)
        Row(
            modifier = Modifier.weight(1f),
            horizontalArrangement = Arrangement.End,
            verticalAlignment = Alignment.CenterVertically
        ) {
            when (activity) {
                is IslandActivity.Media -> {
                    AudioWaveformVisualizer(
                        isPlaying = activity.isPlaying,
                        barCount = 3,
                        barWidth = 2.5.dp,
                        maxHeight = 14.dp,
                        minHeight = 3.dp,
                        color = SpotifyGreen
                    )
                }
                is IslandActivity.AppNotification -> {
                    Text(
                        text = activity.title.ifBlank { activity.appName },
                        color = PureWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                is IslandActivity.Charging -> {
                    Text(
                        text = "${activity.batteryLevel}%",
                        color = ChargingAmber,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                is IslandActivity.PhoneCall -> {
                    Text(
                        text = formatSeconds(activity.callDurationSeconds),
                        color = Color(0xFF4CAF50),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                is IslandActivity.Timer -> {
                    Text(
                        text = formatSeconds(activity.remainingSeconds),
                        color = Color(0xFFFF9800),
                        fontSize = 11.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
                is IslandActivity.BluetoothDevice -> {
                    Text(
                        text = if (activity.isConnected) "Connected" else "Disconnected",
                        color = PureWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Normal
                    )
                }
                is IslandActivity.Volume -> {
                    Text(
                        text = "${activity.volumePercent}%",
                        color = PureWhite,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium
                    )
                }
                is IslandActivity.Idle -> {
                    Box(
                        modifier = Modifier
                            .size(6.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF222222))
                    )
                }
            }
        }
    }
}

private fun formatSeconds(seconds: Long): String {
    val mins = seconds / 60
    val secs = seconds % 60
    return String.format("%02d:%02d", mins, secs)
}
