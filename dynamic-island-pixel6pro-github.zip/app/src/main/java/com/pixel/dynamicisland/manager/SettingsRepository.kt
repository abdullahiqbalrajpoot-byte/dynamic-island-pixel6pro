package com.pixel.dynamicisland.manager

import android.content.Context
import android.content.SharedPreferences
import com.pixel.dynamicisland.model.SettingsState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class SettingsRepository(context: Context) {

    private val prefs: SharedPreferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val _settings = MutableStateFlow(loadSettings())
    val settings: StateFlow<SettingsState> = _settings.asStateFlow()

    private fun loadSettings(): SettingsState {
        return SettingsState(
            isIslandEnabled = prefs.getBoolean(KEY_ISLAND_ENABLED, true),
            showOnLockScreen = prefs.getBoolean(KEY_SHOW_LOCK_SCREEN, true),
            cameraCutoutXOffset = prefs.getInt(KEY_CUTOUT_X_OFFSET, 0),
            cameraCutoutYOffset = prefs.getInt(KEY_CUTOUT_Y_OFFSET, 0),
            pillBaseWidthDp = prefs.getInt(KEY_BASE_WIDTH_DP, 110),
            pillBaseHeightDp = prefs.getInt(KEY_BASE_HEIGHT_DP, 26),
            cornerRadiusDp = prefs.getInt(KEY_CORNER_RADIUS_DP, 13),
            enableMusicIntegration = prefs.getBoolean(KEY_ENABLE_MUSIC, true),
            enableNotifications = prefs.getBoolean(KEY_ENABLE_NOTIFS, true),
            suppressSystemHeadsUp = prefs.getBoolean(KEY_SUPPRESS_HEADS_UP, true),
            enableChargingAnimation = prefs.getBoolean(KEY_ENABLE_CHARGING, true),
            enableVolumeIndicator = prefs.getBoolean(KEY_ENABLE_VOLUME, true),
            enableBluetoothAlerts = prefs.getBoolean(KEY_ENABLE_BLUETOOTH, true),
            enableTimers = prefs.getBoolean(KEY_ENABLE_TIMERS, true),
            notificationDurationSeconds = prefs.getInt(KEY_NOTIF_DURATION, 4),
            animationSpeedMultiplier = prefs.getFloat(KEY_ANIM_SPEED, 1.0f)
        )
    }

    fun updateSettings(newSettings: SettingsState) {
        _settings.value = newSettings
        prefs.edit().apply {
            putBoolean(KEY_ISLAND_ENABLED, newSettings.isIslandEnabled)
            putBoolean(KEY_SHOW_LOCK_SCREEN, newSettings.showOnLockScreen)
            putInt(KEY_CUTOUT_X_OFFSET, newSettings.cameraCutoutXOffset)
            putInt(KEY_CUTOUT_Y_OFFSET, newSettings.cameraCutoutYOffset)
            putInt(KEY_BASE_WIDTH_DP, newSettings.pillBaseWidthDp)
            putInt(KEY_BASE_HEIGHT_DP, newSettings.pillBaseHeightDp)
            putInt(KEY_CORNER_RADIUS_DP, newSettings.cornerRadiusDp)
            putBoolean(KEY_ENABLE_MUSIC, newSettings.enableMusicIntegration)
            putBoolean(KEY_ENABLE_NOTIFS, newSettings.enableNotifications)
            putBoolean(KEY_SUPPRESS_HEADS_UP, newSettings.suppressSystemHeadsUp)
            putBoolean(KEY_ENABLE_CHARGING, newSettings.enableChargingAnimation)
            putBoolean(KEY_ENABLE_VOLUME, newSettings.enableVolumeIndicator)
            putBoolean(KEY_ENABLE_BLUETOOTH, newSettings.enableBluetoothAlerts)
            putBoolean(KEY_ENABLE_TIMERS, newSettings.enableTimers)
            putInt(KEY_NOTIF_DURATION, newSettings.notificationDurationSeconds)
            putFloat(KEY_ANIM_SPEED, newSettings.animationSpeedMultiplier)
            apply()
        }
    }

    fun setCutoutOffsets(xOffset: Int, yOffset: Int) {
        val current = _settings.value
        updateSettings(current.copy(cameraCutoutXOffset = xOffset, cameraCutoutYOffset = yOffset))
    }

    fun setPillDimensions(widthDp: Int, heightDp: Int) {
        val current = _settings.value
        updateSettings(current.copy(pillBaseWidthDp = widthDp, pillBaseHeightDp = heightDp))
    }

    fun toggleIslandEnabled(enabled: Boolean) {
        val current = _settings.value
        updateSettings(current.copy(isIslandEnabled = enabled))
    }

    companion object {
        private const val PREFS_NAME = "dynamic_island_settings"
        private const val KEY_ISLAND_ENABLED = "island_enabled"
        private const val KEY_SHOW_LOCK_SCREEN = "show_lock_screen"
        private const val KEY_CUTOUT_X_OFFSET = "cutout_x_offset"
        private const val KEY_CUTOUT_Y_OFFSET = "cutout_y_offset"
        private const val KEY_BASE_WIDTH_DP = "base_width_dp"
        private const val KEY_BASE_HEIGHT_DP = "base_height_dp"
        private const val KEY_CORNER_RADIUS_DP = "corner_radius_dp"
        private const val KEY_ENABLE_MUSIC = "enable_music"
        private const val KEY_ENABLE_NOTIFS = "enable_notifs"
        private const val KEY_SUPPRESS_HEADS_UP = "suppress_heads_up"
        private const val KEY_ENABLE_CHARGING = "enable_charging"
        private const val KEY_ENABLE_VOLUME = "enable_volume"
        private const val KEY_ENABLE_BLUETOOTH = "enable_bluetooth"
        private const val KEY_ENABLE_TIMERS = "enable_timers"
        private const val KEY_NOTIF_DURATION = "notif_duration"
        private const val KEY_ANIM_SPEED = "anim_speed"

        @Volatile
        private var INSTANCE: SettingsRepository? = null

        fun getInstance(context: Context): SettingsRepository {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: SettingsRepository(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
