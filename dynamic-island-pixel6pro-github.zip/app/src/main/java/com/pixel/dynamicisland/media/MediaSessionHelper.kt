package com.pixel.dynamicisland.media

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.pixel.dynamicisland.manager.IslandStateManager
import com.pixel.dynamicisland.model.IslandActivity
import com.pixel.dynamicisland.service.IslandNotificationListener

class MediaSessionHelper(private val context: Context) {

    private val sessionManager = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
    private var activeController: MediaController? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            updateFromCurrentController()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            updateFromCurrentController()
        }

        override fun onSessionDestroyed() {
            activeController = null
            IslandStateManager.instance.removeActivity(IslandStateManager.KEY_MEDIA)
        }
    }

    fun updateActiveControllers(controllers: List<MediaController>?) {
        if (controllers.isNullOrEmpty()) {
            activeController?.unregisterCallback(callback)
            activeController = null
            IslandStateManager.instance.removeActivity(IslandStateManager.KEY_MEDIA)
            return
        }

        // Find playing controller or first available
        val playing = controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: controllers.firstOrNull()

        if (playing != null && playing != activeController) {
            activeController?.unregisterCallback(callback)
            activeController = playing
            activeController?.registerCallback(callback, mainHandler)
            updateFromCurrentController()
        } else if (playing == null) {
            activeController?.unregisterCallback(callback)
            activeController = null
            IslandStateManager.instance.removeActivity(IslandStateManager.KEY_MEDIA)
        }
    }

    fun updateFromCurrentController() {
        val controller = activeController ?: return
        val metadata = controller.metadata
        val state = controller.playbackState

        val isPlaying = state?.state == PlaybackState.STATE_PLAYING
        val title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            ?: "Unknown Title"
        val artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
            ?: "Unknown Artist"
        val album = metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM)

        val duration = metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val position = state?.position ?: 0L
        val artwork = metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)

        val pkgName = controller.packageName
        val appName = when {
            pkgName.contains("spotify", ignoreCase = true) -> "Spotify"
            pkgName.contains("youtube.music", ignoreCase = true) -> "YouTube Music"
            pkgName.contains("apple.music", ignoreCase = true) -> "Apple Music"
            pkgName.contains("soundcloud", ignoreCase = true) -> "SoundCloud"
            else -> "Music"
        }

        if (isPlaying || state?.state == PlaybackState.STATE_PAUSED) {
            val mediaActivity = IslandActivity.Media(
                title = title,
                artist = artist,
                album = album,
                durationMs = duration,
                currentPositionMs = position,
                isPlaying = isPlaying,
                albumArtwork = artwork,
                appName = appName
            )
            IslandStateManager.instance.postActivity(IslandStateManager.KEY_MEDIA, mediaActivity)
        } else {
            IslandStateManager.instance.removeActivity(IslandStateManager.KEY_MEDIA)
        }
    }

    fun playPause() {
        val controller = activeController ?: return
        val state = controller.playbackState?.state
        if (state == PlaybackState.STATE_PLAYING) {
            controller.transportControls.pause()
        } else {
            controller.transportControls.play()
        }
    }

    fun skipToNext() {
        activeController?.transportControls?.skipToNext()
    }

    fun skipToPrevious() {
        activeController?.transportControls?.skipToPrevious()
    }

    fun seekTo(positionMs: Long) {
        activeController?.transportControls?.seekTo(positionMs)
    }

    companion object {
        @Volatile
        private var INSTANCE: MediaSessionHelper? = null

        fun getInstance(context: Context): MediaSessionHelper {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: MediaSessionHelper(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
