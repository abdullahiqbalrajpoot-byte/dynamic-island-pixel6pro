package com.pixel.dynamicisland.media

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.util.Log
import com.pixel.dynamicisland.manager.IslandStateManager
import com.pixel.dynamicisland.model.IslandActivity
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.InputStream
import java.net.HttpURLConnection
import java.net.URL

class MediaSessionHelper(private val context: Context) {

    private val sessionManager = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as? MediaSessionManager
    private var activeController: MediaController? = null
    private val mainHandler = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(Dispatchers.IO + Job())

    private var lastMediaId: String? = null
    private var cachedArtwork: Bitmap? = null

    private val callback = object : MediaController.Callback() {
        override fun onPlaybackStateChanged(state: PlaybackState?) {
            updateFromCurrentController()
        }

        override fun onMetadataChanged(metadata: MediaMetadata?) {
            updateFromCurrentController()
        }

        override fun onSessionDestroyed() {
            activeController = null
            lastMediaId = null
            cachedArtwork = null
            IslandStateManager.instance.removeActivity(IslandStateManager.KEY_MEDIA)
        }
    }

    fun updateActiveControllers(controllers: List<MediaController>?) {
        if (controllers.isNullOrEmpty()) {
            activeController?.unregisterCallback(callback)
            activeController = null
            lastMediaId = null
            cachedArtwork = null
            IslandStateManager.instance.removeActivity(IslandStateManager.KEY_MEDIA)
            return
        }

        // Prioritize actively playing controller, or retain current/first to listen for resume
        val primary = controllers.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: controllers.firstOrNull()

        if (primary != null) {
            if (primary != activeController) {
                activeController?.unregisterCallback(callback)
                activeController = primary
                activeController?.registerCallback(callback, mainHandler)
            }
            updateFromCurrentController()
        } else {
            activeController?.unregisterCallback(callback)
            activeController = null
            lastMediaId = null
            cachedArtwork = null
            IslandStateManager.instance.removeActivity(IslandStateManager.KEY_MEDIA)
        }
    }

    fun updateFromCurrentController() {
        val controller = activeController ?: return
        val metadata = controller.metadata
        val state = controller.playbackState

        val isPlaying = state?.state == PlaybackState.STATE_PLAYING
        if (!isPlaying) {
            // When music is stopped/paused, remove dynamic island
            IslandStateManager.instance.removeActivity(IslandStateManager.KEY_MEDIA)
            return
        }

        val title = metadata?.getString(MediaMetadata.METADATA_KEY_TITLE)
            ?: metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_TITLE)
            ?: "Unknown Title"
        val artist = metadata?.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_SUBTITLE)
            ?: "Unknown Artist"
        val album = metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM)

        val duration = metadata?.getLong(MediaMetadata.METADATA_KEY_DURATION) ?: 0L
        val position = state?.position ?: 0L

        val currentMediaId = "$title::$artist::$album"
        if (currentMediaId != lastMediaId) {
            lastMediaId = currentMediaId
            val directArt = metadata?.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
                ?: metadata?.getBitmap(MediaMetadata.METADATA_KEY_ART)

            if (directArt != null) {
                cachedArtwork = directArt
            } else {
                val artUriStr = metadata?.getString(MediaMetadata.METADATA_KEY_ALBUM_ART_URI)
                    ?: metadata?.getString(MediaMetadata.METADATA_KEY_ART_URI)
                    ?: metadata?.getString(MediaMetadata.METADATA_KEY_DISPLAY_ICON_URI)

                if (!artUriStr.isNullOrBlank()) {
                    loadArtworkAsync(artUriStr)
                } else {
                    cachedArtwork = null
                }
            }
        }

        val pkgName = controller.packageName
        val appName = when {
            pkgName.contains("spotify", ignoreCase = true) -> "Spotify"
            pkgName.contains("youtube.music", ignoreCase = true) -> "YouTube Music"
            pkgName.contains("apple.music", ignoreCase = true) -> "Apple Music"
            pkgName.contains("soundcloud", ignoreCase = true) -> "SoundCloud"
            else -> "Music"
        }

        val mediaActivity = IslandActivity.Media(
            title = title,
            artist = artist,
            album = album,
            durationMs = duration,
            currentPositionMs = position,
            isPlaying = true,
            albumArtwork = cachedArtwork,
            appName = appName
        )
        IslandStateManager.instance.postActivity(IslandStateManager.KEY_MEDIA, mediaActivity)
    }

    private fun loadArtworkAsync(uriStr: String) {
        scope.launch {
            val bitmap = try {
                if (uriStr.startsWith("http://") || uriStr.startsWith("https://")) {
                    val url = URL(uriStr)
                    val conn = url.openConnection() as HttpURLConnection
                    conn.doInput = true
                    conn.connectTimeout = 3000
                    conn.readTimeout = 3000
                    conn.connect()
                    val input: InputStream = conn.inputStream
                    BitmapFactory.decodeStream(input)
                } else {
                    val uri = Uri.parse(uriStr)
                    context.contentResolver.openInputStream(uri)?.use { stream ->
                        BitmapFactory.decodeStream(stream)
                    }
                }
            } catch (e: Exception) {
                null
            }

            if (bitmap != null) {
                withContext(Dispatchers.Main) {
                    cachedArtwork = bitmap
                    updateFromCurrentController()
                }
            }
        }
    }

    fun playPause() {
        val controller = activeController ?: return
        val state = controller.playbackState?.state
        if (state == PlaybackState.STATE_PLAYING) {
            controller.transportControls.pause()
            IslandStateManager.instance.removeActivity(IslandStateManager.KEY_MEDIA)
        } else {
            controller.transportControls.play()
        }
    }

    fun skipToNext() {
        activeController?.transportControls?.skipToNext()
    }

    fun skipToPrevious() {
        activeController?.transportControls?.skipToPrevious()
    }

    fun seekTo(positionMs: Long) {
        activeController?.transportControls?.seekTo(positionMs)
    }

    companion object {
        @Volatile
        private var INSTANCE: MediaSessionHelper? = null

        fun getInstance(context: Context): MediaSessionHelper {
            return INSTANCE ?: synchronized(this) {
                INSTANCE ?: MediaSessionHelper(context.applicationContext).also { INSTANCE = it }
            }
        }
    }
}
