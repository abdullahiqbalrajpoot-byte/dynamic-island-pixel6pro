package com.pixel.dynamicisland

import android.app.Application
import com.pixel.dynamicisland.manager.SettingsRepository

class DynamicIslandApp : Application() {
    override fun onCreate() {
        super.onCreate()
        // Initialize singletons
        SettingsRepository.getInstance(this)
    }
}
