package com.pixel.dynamicisland.manager

import com.pixel.dynamicisland.model.IslandActivity
import com.pixel.dynamicisland.model.IslandDisplayMode
import com.pixel.dynamicisland.model.IslandState
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.concurrent.ConcurrentHashMap

class IslandStateManager private constructor() {

    private val scope = CoroutineScope(Dispatchers.Main + Job())
    private var autoCollapseJob: Job? = null

    // Map of active activities keyed by category
    private val activeActivities = ConcurrentHashMap<String, IslandActivity>()

    private val _islandState = MutableStateFlow(IslandState())
    val islandState: StateFlow<IslandState> = _islandState.asStateFlow()

    fun postActivity(key: String, activity: IslandActivity) {
        activeActivities[key] = activity
        recalculateState(animateExpansion = true)

        // Schedule auto-collapse if the activity has a timeout
        val timeout = activity.autoCollapseDurationMs
        if (timeout != null && timeout > 0) {
            autoCollapseJob?.cancel()
            autoCollapseJob = scope.launch {
                delay(timeout)
                // If still the same activity, collapse it back to compact
                if (_islandState.value.primaryActivity == activity) {
                    collapseToCompact()
                    // Remove ephemeral activities like charging/volume after collapse
                    if (activity is IslandActivity.Charging || activity is IslandActivity.Volume || activity is IslandActivity.BluetoothDevice) {
                        activeActivities.remove(key)
                        recalculateState(animateExpansion = false)
                    }
                }
            }
        }
    }

    fun removeActivity(key: String) {
        activeActivities.remove(key)
        recalculateState(animateExpansion = false)
    }

    fun clearAllActivities() {
        activeActivities.clear()
        _islandState.value = _islandState.value.copy(
            displayMode = IslandDisplayMode.COMPACT,
            primaryActivity = IslandActivity.Idle,
            secondaryActivity = null
        )
    }

    fun expandToInteractive() {
        val current = _islandState.value
        if (current.primaryActivity != IslandActivity.Idle) {
            autoCollapseJob?.cancel()
            _islandState.value = current.copy(displayMode = IslandDisplayMode.INTERACTIVE)
        }
    }

    fun collapseToCompact() {
        autoCollapseJob?.cancel()
        _islandState.value = _islandState.value.copy(displayMode = IslandDisplayMode.COMPACT)
    }

    fun dismissCurrentActivity() {
        autoCollapseJob?.cancel()
        val primary = _islandState.value.primaryActivity
        if (primary != IslandActivity.Idle) {
            val keyToRemove = activeActivities.entries.firstOrNull { it.value == primary }?.key
            if (keyToRemove != null) {
                activeActivities.remove(keyToRemove)
            }
        }
        recalculateState(animateExpansion = false)
    }

    fun switchNextActivity() {
        val currentSecondary = _islandState.value.secondaryActivity
        if (currentSecondary != null) {
            // Swap primary and secondary
            val currentPrimary = _islandState.value.primaryActivity
            _islandState.value = _islandState.value.copy(
                primaryActivity = currentSecondary,
                secondaryActivity = currentPrimary
            )
        }
    }

    fun updateCutoutOffsets(xOffset: Int, yOffset: Int) {
        _islandState.value = _islandState.value.copy(
            cutoutXOffset = xOffset,
            cutoutYOffset = yOffset
        )
    }

    fun updatePillDimensions(widthDp: Int, heightDp: Int) {
        _islandState.value = _islandState.value.copy(
            basePillWidthDp = widthDp,
            basePillHeightDp = heightDp
        )
    }

    fun setIslandEnabled(enabled: Boolean) {
        _islandState.value = _islandState.value.copy(isEnabled = enabled)
    }

    private fun recalculateState(animateExpansion: Boolean) {
        // Sort active activities by priority descending
        val sorted = activeActivities.values.sortedByDescending { it.priority }
        val primary = sorted.firstOrNull() ?: IslandActivity.Idle
        val secondary = if (sorted.size > 1) sorted[1] else null

        val currentMode = _islandState.value.displayMode
        val newMode = when {
            primary == IslandActivity.Idle -> IslandDisplayMode.COMPACT
            animateExpansion && (primary is IslandActivity.AppNotification || primary is IslandActivity.Charging || primary is IslandActivity.Volume || primary is IslandActivity.BluetoothDevice || primary is IslandActivity.PhoneCall) -> IslandDisplayMode.EXPANDED
            currentMode == IslandDisplayMode.INTERACTIVE -> IslandDisplayMode.INTERACTIVE
            else -> IslandDisplayMode.COMPACT
        }

        _islandState.value = _islandState.value.copy(
            primaryActivity = primary,
            secondaryActivity = secondary,
            displayMode = newMode
        )
    }

    companion object {
        val instance = IslandStateManager()

        // Standard activity keys
        const val KEY_PHONE_CALL = "call"
        const val KEY_TIMER = "timer"
        const val KEY_CHARGING = "charging"
        const val KEY_VOLUME = "volume"
        const val KEY_BLUETOOTH = "bluetooth"
        const val KEY_NOTIFICATION = "notification"
        const val KEY_MEDIA = "media"
    }
}
