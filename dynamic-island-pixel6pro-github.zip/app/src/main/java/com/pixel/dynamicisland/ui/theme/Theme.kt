package com.pixel.dynamicisland.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkColorScheme = darkColorScheme(
    primary = PixelCyan,
    secondary = SpotifyGreen,
    tertiary = SurfaceElevated,
    background = PureBlack,
    surface = DarkCharcoal,
    onPrimary = PureBlack,
    onSecondary = PureBlack,
    onBackground = PureWhite,
    onSurface = PureWhite,
    surfaceVariant = SurfaceDark,
    onSurfaceVariant = TextSecondary
)

@Composable
fun DynamicIslandTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        content = content
    )
}
