package com.pixel.dynamicisland.media

import android.graphics.Bitmap

data class MusicTrackInfo(
    val title: String,
    val artist: String,
    val album: String? = null,
    val durationMs: Long = 0,
    val currentPositionMs: Long = 0,
    val isPlaying: Boolean = false,
    val albumArt: Bitmap? = null,
    val appPackage: String? = null,
    val appName: String = "Music"
)
