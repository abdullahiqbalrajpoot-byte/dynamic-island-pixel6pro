package com.pixel.dynamicisland.model

import android.app.PendingIntent
import android.graphics.Bitmap
import android.graphics.drawable.Icon

/**
 * Represents the distinct types of events that can occupy the Dynamic Island.
 */
sealed class IslandActivity(
    val priority: Int, // Higher number = higher priority
    val autoCollapseDurationMs: Long? = null // Null = stays active until dismissed/paused
) {
    // Priority 1: Phone Calls
    data class PhoneCall(
        val callerName: String,
        val callerNumber: String? = null,
        val contactPhoto: Bitmap? = null,
        val isIncoming: Boolean,
        val callDurationSeconds: Long = 0
    ) : IslandActivity(priority = 100, autoCollapseDurationMs = null)

    // Priority 2: Timers & Stopwatches
    data class Timer(
        val label: String,
        val remainingSeconds: Long,
        val totalSeconds: Long,
        val isPaused: Boolean = false
    ) : IslandActivity(priority = 80, autoCollapseDurationMs = null)

    // Priority 3: Ephemeral System Events (Charging, Volume, Bluetooth)
    data class Charging(
        val batteryLevel: Int,
        val isFastCharging: Boolean = false
    ) : IslandActivity(priority = 60, autoCollapseDurationMs = 3500L)

    data class Volume(
        val volumePercent: Int,
        val maxVolume: Int = 100,
        val isMuted: Boolean = false
    ) : IslandActivity(priority = 55, autoCollapseDurationMs = 2500L)

    data class BluetoothDevice(
        val deviceName: String,
        val isConnected: Boolean,
        val batteryPercent: Int? = null
    ) : IslandActivity(priority = 50, autoCollapseDurationMs = 3500L)

    // Priority 4: Incoming Notifications
    data class AppNotification(
        val id: String,
        val packageName: String,
        val appName: String,
        val title: String,
        val text: String,
        val appIcon: Bitmap? = null,
        val smallIcon: Icon? = null,
        val contentIntent: PendingIntent? = null
    ) : IslandActivity(priority = 40, autoCollapseDurationMs = 4500L)

    // Priority 5: Active Music / Media Playback
    data class Media(
        val title: String,
        val artist: String,
        val album: String? = null,
        val durationMs: Long = 0,
        val currentPositionMs: Long = 0,
        val isPlaying: Boolean = true,
        val albumArtwork: Bitmap? = null,
        val appName: String = "Spotify"
    ) : IslandActivity(priority = 20, autoCollapseDurationMs = null)

    // Default Idle State
    object Idle : IslandActivity(priority = 0, autoCollapseDurationMs = null)
}
