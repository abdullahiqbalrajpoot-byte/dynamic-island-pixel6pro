package com.pixel.dynamicisland.ui.island

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pixel.dynamicisland.model.IslandActivity
import com.pixel.dynamicisland.ui.theme.PureWhite

@Composable
fun ExpandedVolumeView(
    volume: IslandActivity.Volume,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Icon(
            imageVector = if (volume.isMuted) Icons.Default.VolumeMute else Icons.Default.VolumeUp,
            contentDescription = "Volume",
            tint = PureWhite,
            modifier = Modifier.size(24.dp)
        )

        Spacer(modifier = Modifier.width(14.dp))

        val progress = (volume.volumePercent.toFloat() / volume.maxVolume.toFloat()).coerceIn(0f, 1f)

        LinearProgressIndicator(
            progress = { progress },
            modifier = Modifier
                .weight(1f)
                .height(6.dp)
                .clip(RoundedCornerShape(3.dp)),
            color = PureWhite,
            trackColor = Color(0xFF333333)
        )

        Spacer(modifier = Modifier.width(14.dp))

        Text(
            text = "${volume.volumePercent}%",
            color = PureWhite,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
    }
}
