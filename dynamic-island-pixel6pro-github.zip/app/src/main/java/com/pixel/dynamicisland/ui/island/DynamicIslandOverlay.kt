package com.pixel.dynamicisland.ui.island

import android.content.Intent
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.pixel.dynamicisland.model.IslandActivity
import com.pixel.dynamicisland.model.IslandDisplayMode
import com.pixel.dynamicisland.model.IslandState
import com.pixel.dynamicisland.ui.theme.PureBlack

@Composable
fun DynamicIslandOverlay(
    state: IslandState,
    onTap: () -> Unit,
    onLongPress: () -> Unit,
    onSwipeUp: () -> Unit,
    onSwipeHorizontal: () -> Unit,
    onDismissActivity: () -> Unit,
    onMusicPlayPause: () -> Unit,
    onMusicSkipNext: () -> Unit,
    onMusicSkipPrevious: () -> Unit,
    modifier: Modifier = Modifier
) {
    // If disabled or idle (e.g. music stopped/paused with no pending alerts), completely hide
    if (!state.isEnabled || state.primaryActivity is IslandActivity.Idle) return

    val context = LocalContext.current

    val targetWidth = when (state.displayMode) {
        IslandDisplayMode.COMPACT -> state.basePillWidthDp.dp
        IslandDisplayMode.EXPANDED -> when (state.primaryActivity) {
            is IslandActivity.AppNotification -> 350.dp
            is IslandActivity.Charging -> 260.dp
            is IslandActivity.Volume -> 240.dp
            is IslandActivity.PhoneCall -> 320.dp
            else -> 320.dp
        }
        IslandDisplayMode.INTERACTIVE -> 350.dp
        IslandDisplayMode.DISMISSED -> 40.dp
    }

    val targetHeight = when (state.displayMode) {
        IslandDisplayMode.COMPACT -> state.basePillHeightDp.dp
        IslandDisplayMode.EXPANDED -> when (state.primaryActivity) {
            is IslandActivity.AppNotification -> 88.dp
            is IslandActivity.PhoneCall -> 76.dp
            else -> 66.dp
        }
        IslandDisplayMode.INTERACTIVE -> when (state.primaryActivity) {
            is IslandActivity.Media -> 164.dp
            is IslandActivity.PhoneCall -> 80.dp
            is IslandActivity.Timer -> 72.dp
            else -> 88.dp
        }
        IslandDisplayMode.DISMISSED -> 30.dp
    }

    val cornerRadius = when (state.displayMode) {
        IslandDisplayMode.COMPACT -> (state.basePillHeightDp / 2).dp
        IslandDisplayMode.DISMISSED -> (state.basePillHeightDp / 2).dp
        else -> 32.dp
    }

    // Fluid liquid spring physics matching Apple Dynamic Island
    val animatedWidth by animateDpAsState(
        targetValue = targetWidth,
        animationSpec = spring(
            dampingRatio = 0.72f,
            stiffness = 400f
        ),
        label = "IslandWidth"
    )

    val animatedHeight by animateDpAsState(
        targetValue = targetHeight,
        animationSpec = spring(
            dampingRatio = 0.72f,
            stiffness = 400f
        ),
        label = "IslandHeight"
    )

    val animatedCornerRadius by animateDpAsState(
        targetValue = cornerRadius,
        animationSpec = spring(
            dampingRatio = 0.72f,
            stiffness = 400f
        ),
        label = "IslandCornerRadius"
    )

    // Gesture modifier: In compact mode, tapping expands to interactive; in expanded/interactive, swiping up collapses
    val gestureModifier = if (state.displayMode == IslandDisplayMode.COMPACT) {
        Modifier.clickable(
            interactionSource = remember { MutableInteractionSource() },
            indication = null
        ) {
            onTap()
        }
    } else {
        Modifier.pointerInput(Unit) {
            detectVerticalDragGestures { _, dragAmount ->
                if (dragAmount < -15f) {
                    onSwipeUp()
                }
            }
        }
    }

    // Main Floating Pill
    Box(
        modifier = modifier
            .width(animatedWidth)
            .height(animatedHeight)
            .shadow(
                elevation = if (state.displayMode != IslandDisplayMode.COMPACT) 16.dp else 6.dp,
                shape = RoundedCornerShape(animatedCornerRadius),
                ambientColor = Color.Black,
                spotColor = Color.Black
            )
            .clip(RoundedCornerShape(animatedCornerRadius))
            .background(PureBlack)
            .then(gestureModifier),
        contentAlignment = Alignment.Center
    ) {
        AnimatedContent(
            targetState = state.displayMode to state.primaryActivity,
            transitionSpec = {
                (fadeIn(animationSpec = spring(stiffness = 500f)) +
                 scaleIn(initialScale = 0.88f, animationSpec = spring(dampingRatio = 0.72f, stiffness = 400f)))
                .togetherWith(
                 fadeOut(animationSpec = spring(stiffness = 800f)) +
                 scaleOut(targetScale = 0.92f, animationSpec = spring(stiffness = 800f))
                )
            },
            label = "IslandContentTransition"
        ) { (mode, activity) ->
            when (mode) {
                IslandDisplayMode.COMPACT -> {
                    CompactIslandView(activity = activity)
                }
                IslandDisplayMode.EXPANDED, IslandDisplayMode.INTERACTIVE -> {
                    when (activity) {
                        is IslandActivity.Media -> {
                            ExpandedMusicView(
                                media = activity,
                                onPlayPause = onMusicPlayPause,
                                onSkipNext = onMusicSkipNext,
                                onSkipPrevious = onMusicSkipPrevious
                            )
                        }
                        is IslandActivity.AppNotification -> {
                            ExpandedNotificationView(
                                notification = activity,
                                onDismiss = onDismissActivity,
                                onOpenNotification = {
                                    try {
                                        activity.contentIntent?.send()
                                    } catch (e: Exception) {
                                        val launchIntent = context.packageManager.getLaunchIntentForPackage(activity.packageName)
                                        if (launchIntent != null) {
                                            launchIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                            context.startActivity(launchIntent)
                                        }
                                    }
                                    onDismissActivity()
                                }
                            )
                        }
                        is IslandActivity.Charging -> {
                            ExpandedChargingView(charging = activity)
                        }
                        is IslandActivity.Volume -> {
                            ExpandedVolumeView(volume = activity)
                        }
                        is IslandActivity.PhoneCall -> {
                            ExpandedCallView(
                                call = activity,
                                onAnswer = onDismissActivity,
                                onDecline = onDismissActivity
                            )
                        }
                        is IslandActivity.Timer -> {
                            ExpandedTimerView(
                                timer = activity,
                                onTogglePause = {},
                                onReset = onDismissActivity
                            )
                        }
                        else -> {
                            CompactIslandView(activity = activity)
                        }
                    }
                }
                IslandDisplayMode.DISMISSED -> {
                    Box(modifier = Modifier.height(30.dp))
                }
            }
        }
    }
}
