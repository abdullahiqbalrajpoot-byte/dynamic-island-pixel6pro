package com.pixel.dynamicisland.ui.island

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import com.pixel.dynamicisland.model.IslandActivity
import com.pixel.dynamicisland.model.IslandDisplayMode
import com.pixel.dynamicisland.model.IslandState
import com.pixel.dynamicisland.ui.theme.PureBlack

@Composable
fun DynamicIslandOverlay(
    state: IslandState,
    onTap: () -> Unit,
    onLongPress: () -> Unit,
    onSwipeUp: () -> Unit,
    onSwipeHorizontal: () -> Unit,
    onDismissActivity: () -> Unit,
    onMusicPlayPause: () -> Unit,
    onMusicSkipNext: () -> Unit,
    onMusicSkipPrevious: () -> Unit,
    modifier: Modifier = Modifier
) {
    if (!state.isEnabled) return

    val targetWidth = when (state.displayMode) {
        IslandDisplayMode.COMPACT -> state.basePillWidthDp.dp
        IslandDisplayMode.EXPANDED -> when (state.primaryActivity) {
            is IslandActivity.Charging -> 260.dp
            is IslandActivity.Volume -> 240.dp
            is IslandActivity.PhoneCall -> 310.dp
            else -> 320.dp
        }
        IslandDisplayMode.INTERACTIVE -> 350.dp
        IslandDisplayMode.DISMISSED -> 40.dp
    }

    val targetHeight = when (state.displayMode) {
        IslandDisplayMode.COMPACT -> state.basePillHeightDp.dp
        IslandDisplayMode.EXPANDED -> 64.dp
        IslandDisplayMode.INTERACTIVE -> when (state.primaryActivity) {
            is IslandActivity.Media -> 160.dp
            is IslandActivity.PhoneCall -> 76.dp
            is IslandActivity.Timer -> 68.dp
            else -> 80.dp
        }
        IslandDisplayMode.DISMISSED -> 30.dp
    }

    val cornerRadius = when (state.displayMode) {
        IslandDisplayMode.COMPACT -> (state.basePillHeightDp / 2).dp
        IslandDisplayMode.DISMISSED -> (state.basePillHeightDp / 2).dp
        else -> 32.dp
    }

    val animatedWidth by animateDpAsState(
        targetValue = targetWidth,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "IslandWidth"
    )

    val animatedHeight by animateDpAsState(
        targetValue = targetHeight,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "IslandHeight"
    )

    // Main Floating Pill
    Box(
        modifier = modifier
            .offset { IntOffset(state.cutoutXOffset, state.cutoutYOffset) }
            .width(animatedWidth)
            .height(animatedHeight)
            .shadow(
                elevation = if (state.displayMode != IslandDisplayMode.COMPACT) 16.dp else 6.dp,
                shape = RoundedCornerShape(cornerRadius),
                ambientColor = Color.Black,
                spotColor = Color.Black
            )
            .clip(RoundedCornerShape(cornerRadius))
            .background(PureBlack)
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                onTap()
            }
            .pointerInput(Unit) {
                detectDragGestures { change, dragAmount ->
                    change.consume()
                    // Vertical drag up collapses
                    if (dragAmount.y < -12f) {
                        onSwipeUp()
                    }
                    // Horizontal drag switches activity
                    else if (kotlin.math.abs(dragAmount.x) > 20f) {
                        onSwipeHorizontal()
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        AnimatedContent(
            targetState = state.displayMode to state.primaryActivity,
            transitionSpec = {
                fadeIn(animationSpec = spring(stiffness = Spring.StiffnessHigh)) togetherWith
                        fadeOut(animationSpec = spring(stiffness = Spring.StiffnessHigh))
            },
            label = "IslandContentTransition"
        ) { (mode, activity) ->
            when (mode) {
                IslandDisplayMode.COMPACT -> {
                    CompactIslandView(activity = activity)
                }
                IslandDisplayMode.EXPANDED, IslandDisplayMode.INTERACTIVE -> {
                    when (activity) {
                        is IslandActivity.Media -> {
                            ExpandedMusicView(
                                media = activity,
                                onPlayPause = onMusicPlayPause,
                                onSkipNext = onMusicSkipNext,
                                onSkipPrevious = onMusicSkipPrevious
                            )
                        }
                        is IslandActivity.AppNotification -> {
                            ExpandedNotificationView(
                                notification = activity,
                                onDismiss = onDismissActivity
                            )
                        }
                        is IslandActivity.Charging -> {
                            ExpandedChargingView(charging = activity)
                        }
                        is IslandActivity.Volume -> {
                            ExpandedVolumeView(volume = activity)
                        }
                        is IslandActivity.PhoneCall -> {
                            ExpandedCallView(
                                call = activity,
                                onAnswer = onDismissActivity,
                                onDecline = onDismissActivity
                            )
                        }
                        is IslandActivity.Timer -> {
                            ExpandedTimerView(
                                timer = activity,
                                onTogglePause = {},
                                onReset = onDismissActivity
                            )
                        }
                        else -> {
                            CompactIslandView(activity = activity)
                        }
                    }
                }
                IslandDisplayMode.DISMISSED -> {
                    Box(modifier = Modifier.height(30.dp))
                }
            }
        }
    }
}
