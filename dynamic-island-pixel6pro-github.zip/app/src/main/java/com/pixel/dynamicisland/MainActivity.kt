package com.pixel.dynamicisland

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.lifecycle.lifecycleScope
import com.pixel.dynamicisland.manager.IslandStateManager
import com.pixel.dynamicisland.manager.PermissionManager
import com.pixel.dynamicisland.manager.SettingsRepository
import com.pixel.dynamicisland.service.DynamicIslandOverlayService
import com.pixel.dynamicisland.ui.settings.CalibrationScreen
import com.pixel.dynamicisland.ui.settings.OnboardingScreen
import com.pixel.dynamicisland.ui.settings.SettingsScreen
import com.pixel.dynamicisland.ui.theme.DynamicIslandTheme
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {

    private lateinit var settingsRepo: SettingsRepository

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        settingsRepo = SettingsRepository.getInstance(this)

        setContent {
            val settings by settingsRepo.settings.collectAsState()
            var currentScreen by remember { mutableStateOf<Screen>(Screen.Settings) }
            var hasOverlayPermission by remember { mutableStateOf(PermissionManager.hasOverlayPermission(this)) }
            var hasNotifPermission by remember { mutableStateOf(PermissionManager.hasNotificationListenerPermission(this)) }

            // Check permissions on resume
            LaunchedEffect(Unit) {
                hasOverlayPermission = PermissionManager.hasOverlayPermission(this@MainActivity)
                hasNotifPermission = PermissionManager.hasNotificationListenerPermission(this@MainActivity)
                if (!hasOverlayPermission) {
                    currentScreen = Screen.Onboarding
                }
            }

            DynamicIslandTheme {
                when (currentScreen) {
                    Screen.Onboarding -> {
                        OnboardingScreen(
                            hasOverlayPermission = hasOverlayPermission,
                            hasNotificationPermission = hasNotifPermission,
                            onRequestOverlay = {
                                PermissionManager.openOverlaySettings(this@MainActivity)
                            },
                            onRequestNotification = {
                                PermissionManager.openNotificationListenerSettings(this@MainActivity)
                            },
                            onFinishOnboarding = {
                                DynamicIslandOverlayService.start(this@MainActivity)
                                currentScreen = Screen.Settings
                            }
                        )
                    }

                    Screen.Settings -> {
                        SettingsScreen(
                            settings = settings,
                            onUpdateSettings = { newSettings ->
                                settingsRepo.updateSettings(newSettings)
                                if (newSettings.isIslandEnabled) {
                                    DynamicIslandOverlayService.start(this@MainActivity)
                                } else {
                                    DynamicIslandOverlayService.stop(this@MainActivity)
                                }
                            },
                            onOpenCalibration = {
                                currentScreen = Screen.Calibration
                            },
                            onTriggerTestActivity = { activity ->
                                IslandStateManager.instance.postActivity("test", activity)
                            }
                        )
                    }

                    Screen.Calibration -> {
                        CalibrationScreen(
                            currentSettings = settings,
                            onSaveCalibration = { xOffset, yOffset, widthDp, heightDp ->
                                settingsRepo.setCutoutOffsets(xOffset, yOffset)
                                settingsRepo.setPillDimensions(widthDp, heightDp)
                            },
                            onBack = {
                                currentScreen = Screen.Settings
                            }
                        )
                    }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (PermissionManager.hasOverlayPermission(this) && settingsRepo.settings.value.isIslandEnabled) {
            DynamicIslandOverlayService.start(this)
        }
    }

    sealed class Screen {
        object Onboarding : Screen()
        object Settings : Screen()
        object Calibration : Screen()
    }
}
