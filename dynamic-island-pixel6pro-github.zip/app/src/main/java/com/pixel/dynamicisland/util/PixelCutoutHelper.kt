package com.pixel.dynamicisland.util

import android.content.Context
import android.graphics.Rect
import android.os.Build
import android.view.DisplayCutout
import android.view.WindowInsets
import android.view.WindowManager

object PixelCutoutHelper {

    // Default Pixel 6 Pro specifications in density-independent pixels (dp)
    const val PIXEL_6_PRO_CUTOUT_WIDTH_DP = 34
    const val PIXEL_6_PRO_CUTOUT_HEIGHT_DP = 34
    const val PIXEL_6_PRO_STATUS_BAR_HEIGHT_DP = 42

    fun getCameraCutoutBounds(context: Context, insets: WindowInsets? = null): Rect? {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            val cutout: DisplayCutout? = insets?.displayCutout
            if (cutout != null && cutout.boundingRects.isNotEmpty()) {
                // Return top center cutout if present
                val topCutout = cutout.boundingRects.firstOrNull { it.top == 0 || it.top < 150 }
                if (topCutout != null) return topCutout
            }
        }
        return null
    }

    fun getEstimatedCutoutCenterYDp(context: Context): Int {
        val density = context.resources.displayMetrics.density
        val statusBarHeightPx = getStatusBarHeightPx(context)
        val statusBarHeightDp = (statusBarHeightPx / density).toInt()
        return (statusBarHeightDp / 2).coerceAtLeast(18)
    }

    fun getStatusBarHeightPx(context: Context): Int {
        val resourceId = context.resources.getIdentifier("status_bar_height", "dimen", "android")
        return if (resourceId > 0) {
            context.resources.getDimensionPixelSize(resourceId)
        } else {
            (42 * context.resources.displayMetrics.density).toInt()
        }
    }
}
