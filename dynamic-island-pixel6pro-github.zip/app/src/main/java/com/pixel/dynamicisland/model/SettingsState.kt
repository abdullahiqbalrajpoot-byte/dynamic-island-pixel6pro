package com.pixel.dynamicisland.model

/**
 * Settings configuration for the Dynamic Island.
 */
data class SettingsState(
    val isIslandEnabled: Boolean = true,
    val showOnLockScreen: Boolean = true,
    // Calibration for Pixel 6 Pro center camera
    val cameraCutoutXOffset: Int = 0,
    val cameraCutoutYOffset: Int = 0,
    val pillBaseWidthDp: Int = 110,
    val pillBaseHeightDp: Int = 34,
    val cornerRadiusDp: Int = 20,
    // Feature Toggles
    val enableMusicIntegration: Boolean = true,
    val enableNotifications: Boolean = true,
    val enableChargingAnimation: Boolean = true,
    val enableVolumeIndicator: Boolean = true,
    val enableBluetoothAlerts: Boolean = true,
    val enableTimers: Boolean = true,
    // Timing
    val notificationDurationSeconds: Int = 4,
    val animationSpeedMultiplier: Float = 1.0f
)
