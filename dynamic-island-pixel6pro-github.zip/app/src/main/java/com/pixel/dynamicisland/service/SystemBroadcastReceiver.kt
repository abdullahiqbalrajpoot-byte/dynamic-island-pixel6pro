package com.pixel.dynamicisland.service

import android.bluetooth.BluetoothDevice
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.os.Build
import com.pixel.dynamicisland.manager.IslandStateManager
import com.pixel.dynamicisland.manager.SettingsRepository
import com.pixel.dynamicisland.model.IslandActivity

class SystemBroadcastReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val settings = SettingsRepository.getInstance(context).settings.value
        if (!settings.isIslandEnabled) return

        when (intent.action) {
            Intent.ACTION_BOOT_COMPLETED -> {
                // Auto-start overlay service if permitted
                if (settings.isIslandEnabled) {
                    val serviceIntent = Intent(context, DynamicIslandOverlayService::class.java)
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                        context.startForegroundService(serviceIntent)
                    } else {
                        context.startService(serviceIntent)
                    }
                }
            }

            Intent.ACTION_POWER_CONNECTED -> {
                if (settings.enableChargingAnimation) {
                    val batteryIntent = context.registerReceiver(null, android.content.IntentFilter(Intent.ACTION_BATTERY_CHANGED))
                    val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: 80
                    val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: 100
                    val batteryPct = if (level >= 0 && scale > 0) ((level / scale.toFloat()) * 100).toInt() else 80

                    val chargingActivity = IslandActivity.Charging(
                        batteryLevel = batteryPct,
                        isFastCharging = true
                    )
                    IslandStateManager.instance.postActivity(IslandStateManager.KEY_CHARGING, chargingActivity)
                }
            }

            Intent.ACTION_POWER_DISCONNECTED -> {
                IslandStateManager.instance.removeActivity(IslandStateManager.KEY_CHARGING)
            }

            BluetoothDevice.ACTION_ACL_CONNECTED -> {
                if (settings.enableBluetoothAlerts) {
                    val device = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    }
                    val name = device?.name ?: "Bluetooth Accessory"
                    val btActivity = IslandActivity.BluetoothDevice(
                        deviceName = name,
                        isConnected = true
                    )
                    IslandStateManager.instance.postActivity(IslandStateManager.KEY_BLUETOOTH, btActivity)
                }
            }

            BluetoothDevice.ACTION_ACL_DISCONNECTED -> {
                if (settings.enableBluetoothAlerts) {
                    val device = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice::class.java)
                    } else {
                        @Suppress("DEPRECATION")
                        intent.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE)
                    }
                    val name = device?.name ?: "Bluetooth Device"
                    val btActivity = IslandActivity.BluetoothDevice(
                        deviceName = name,
                        isConnected = false
                    )
                    IslandStateManager.instance.postActivity(IslandStateManager.KEY_BLUETOOTH, btActivity)
                }
            }
        }
    }
}
