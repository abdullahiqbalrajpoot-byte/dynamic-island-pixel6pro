package com.pixel.dynamicisland.ui.theme

import androidx.compose.ui.graphics.Color

val PureBlack = Color(0xFF000000)
val DarkCharcoal = Color(0xFF121212)
val SurfaceDark = Color(0xFF1E1E1E)
val SurfaceElevated = Color(0xFF282828)
val PureWhite = Color(0xFFFFFFFF)
val TextSecondary = Color(0xFFA0A0A0)
val TextTertiary = Color(0xFF6E6E6E)
val SpotifyGreen = Color(0xFF1DB954)
val PixelCyan = Color(0xFF00E5FF)
val WarningOrange = Color(0xFFFF9800)
val CallGreen = Color(0xFF4CAF50)
val CallRed = Color(0xFFF44336)
val ChargingAmber = Color(0xFFFFD600)
