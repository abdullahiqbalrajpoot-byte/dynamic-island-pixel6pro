package com.pixel.dynamicisland.manager

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.pixel.dynamicisland.media.MediaSessionHelper
import com.pixel.dynamicisland.model.IslandActivity
import com.pixel.dynamicisland.model.IslandDisplayMode
import com.pixel.dynamicisland.model.IslandState
import com.pixel.dynamicisland.ui.island.DynamicIslandOverlay
import com.pixel.dynamicisland.ui.theme.DynamicIslandTheme
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

class IslandWindowManager(
    private val context: Context
) : LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()
    private val scope = CoroutineScope(Dispatchers.Main + Job())

    private var overlayComposeView: ComposeView? = null
    private var windowLayoutParams: WindowManager.LayoutParams? = null
    private var isOverlayAttached = false
    private val mediaHelper = MediaSessionHelper.getInstance(context)

    override val lifecycle: Lifecycle = lifecycleRegistry
    override val viewModelStore: ViewModelStore = store
    override val savedStateRegistry: SavedStateRegistry = savedStateRegistryController.savedStateRegistry

    init {
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
    }

    fun showOverlay() {
        if (isOverlayAttached) return

        val density = context.resources.displayMetrics.density
        // Pixel 6 Pro front camera center is ~21dp from top; for a 26dp pill, top starts at 8dp
        val defaultTopMarginPx = (8 * density).toInt()

        val params = WindowManager.LayoutParams().apply {
            type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }

            // NOT_FOCUSABLE lets touches pass through to apps below unless tapped on the island
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }

            format = PixelFormat.TRANSLUCENT
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            width = ((110 + 24) * density).toInt()
            height = ((26 + 20) * density).toInt()
            x = 0
            y = defaultTopMarginPx
        }
        windowLayoutParams = params

        val composeView = ComposeView(context).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindowOrReleasedFromPool)
            setViewTreeLifecycleOwner(this@IslandWindowManager)
            setViewTreeViewModelStoreOwner(this@IslandWindowManager)
            setViewTreeSavedStateRegistryOwner(this@IslandWindowManager)

            setContent {
                val state by IslandStateManager.instance.islandState.collectAsState()

                DynamicIslandTheme {
                    DynamicIslandOverlay(
                        state = state,
                        onTap = {
                            if (state.displayMode == IslandDisplayMode.COMPACT) {
                                IslandStateManager.instance.expandToInteractive()
                            } else {
                                IslandStateManager.instance.collapseToCompact()
                            }
                        },
                        onLongPress = {
                            IslandStateManager.instance.expandToInteractive()
                        },
                        onSwipeUp = {
                            IslandStateManager.instance.collapseToCompact()
                        },
                        onSwipeHorizontal = {
                            IslandStateManager.instance.switchNextActivity()
                        },
                        onDismissActivity = {
                            IslandStateManager.instance.dismissCurrentActivity()
                        },
                        onMusicPlayPause = {
                            mediaHelper.playPause()
                        },
                        onMusicSkipNext = {
                            mediaHelper.skipToNext()
                        },
                        onMusicSkipPrevious = {
                            mediaHelper.skipToPrevious()
                        }
                    )
                }
            }
        }

        try {
            windowManager.addView(composeView, params)
            overlayComposeView = composeView
            isOverlayAttached = true

            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)

            // Continuously observe state and dynamically adapt WindowManager window bounds & visibility
            scope.launch {
                IslandStateManager.instance.islandState.collect { state ->
                    updateWindowLayout(state)
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    private fun updateWindowLayout(state: IslandState) {
        val view = overlayComposeView ?: return
        val params = windowLayoutParams ?: return
        val density = context.resources.displayMetrics.density

        // Completely hide the overlay when disabled or idle (e.g. music stopped/paused, no active events)
        if (!state.isEnabled || state.primaryActivity is IslandActivity.Idle) {
            view.visibility = View.GONE
            return
        } else {
            view.visibility = View.VISIBLE
        }

        // Dynamically size WindowManager window to provide full hit-box coverage for interactive controls
        val (targetWidthDp, targetHeightDp) = when (state.displayMode) {
            IslandDisplayMode.COMPACT -> Pair(state.basePillWidthDp + 24, state.basePillHeightDp + 20)
            IslandDisplayMode.EXPANDED -> when (state.primaryActivity) {
                is IslandActivity.AppNotification -> Pair(364, 100)
                else -> Pair(336, 80)
            }
            IslandDisplayMode.INTERACTIVE -> when (state.primaryActivity) {
                is IslandActivity.Media -> Pair(364, 180)
                else -> Pair(364, 100)
            }
            IslandDisplayMode.DISMISSED -> Pair(50, 40)
        }

        val targetWidthPx = (targetWidthDp * density).toInt()
        val targetHeightPx = (targetHeightDp * density).toInt()
        val topMarginPx = ((8 + state.cutoutYOffset) * density).toInt()
        val xOffsetPx = (state.cutoutXOffset * density).toInt()

        var layoutChanged = false
        if (params.width != targetWidthPx) {
            params.width = targetWidthPx
            layoutChanged = true
        }
        if (params.height != targetHeightPx) {
            params.height = targetHeightPx
            layoutChanged = true
        }
        if (params.y != topMarginPx) {
            params.y = topMarginPx
            layoutChanged = true
        }
        if (params.x != xOffsetPx) {
            params.x = xOffsetPx
            layoutChanged = true
        }

        if (layoutChanged && isOverlayAttached) {
            try {
                windowManager.updateViewLayout(view, params)
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun hideOverlay() {
        if (!isOverlayAttached) return

        try {
            overlayComposeView?.let { windowManager.removeView(it) }
            overlayComposeView = null
            windowLayoutParams = null
            isOverlayAttached = false

            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun destroy() {
        hideOverlay()
        scope.cancel()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
    }
}
