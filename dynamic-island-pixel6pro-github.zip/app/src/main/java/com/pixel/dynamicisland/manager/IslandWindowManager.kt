package com.pixel.dynamicisland.manager

import android.content.Context
import android.graphics.PixelFormat
import android.os.Build
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.platform.ComposeView
import androidx.compose.ui.platform.ViewCompositionStrategy
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleOwner
import androidx.lifecycle.LifecycleRegistry
import androidx.lifecycle.ViewModelStore
import androidx.lifecycle.ViewModelStoreOwner
import androidx.lifecycle.setViewTreeLifecycleOwner
import androidx.lifecycle.setViewTreeViewModelStoreOwner
import androidx.savedstate.SavedStateRegistry
import androidx.savedstate.SavedStateRegistryController
import androidx.savedstate.SavedStateRegistryOwner
import androidx.savedstate.setViewTreeSavedStateRegistryOwner
import com.pixel.dynamicisland.media.MediaSessionHelper
import com.pixel.dynamicisland.model.IslandDisplayMode
import com.pixel.dynamicisland.ui.island.DynamicIslandOverlay
import com.pixel.dynamicisland.ui.theme.DynamicIslandTheme

class IslandWindowManager(
    private val context: Context
) : LifecycleOwner, ViewModelStoreOwner, SavedStateRegistryOwner {

    private val windowManager = context.getSystemService(Context.WINDOW_SERVICE) as WindowManager
    private val lifecycleRegistry = LifecycleRegistry(this)
    private val savedStateRegistryController = SavedStateRegistryController.create(this)
    private val store = ViewModelStore()

    private var overlayComposeView: ComposeView? = null
    private var isOverlayAttached = false
    private val mediaHelper = MediaSessionHelper.getInstance(context)

    override val lifecycle: Lifecycle = lifecycleRegistry
    override val viewModelStore: ViewModelStore = store
    override val savedStateRegistry: SavedStateRegistry = savedStateRegistryController.savedStateRegistry

    init {
        savedStateRegistryController.performRestore(null)
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_CREATE)
    }

    fun showOverlay() {
        if (isOverlayAttached) return

        val density = context.resources.displayMetrics.density
        // Default top margin to position pill naturally around punch-hole lens with clean spacing
        val defaultTopMarginPx = (11 * density).toInt()

        val params = WindowManager.LayoutParams().apply {
            type = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            } else {
                @Suppress("DEPRECATION")
                WindowManager.LayoutParams.TYPE_PHONE
            }

            // NOT_FOCUSABLE lets touches pass through to apps below unless tapped on the island
            flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                    WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                    WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
            }

            format = PixelFormat.TRANSLUCENT
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL
            width = WindowManager.LayoutParams.WRAP_CONTENT
            height = WindowManager.LayoutParams.WRAP_CONTENT
            x = 0
            y = defaultTopMarginPx
        }

        val composeView = ComposeView(context).apply {
            setViewCompositionStrategy(ViewCompositionStrategy.DisposeOnDetachedFromWindowOrReleasedFromPool)
            setViewTreeLifecycleOwner(this@IslandWindowManager)
            setViewTreeViewModelStoreOwner(this@IslandWindowManager)
            setViewTreeSavedStateRegistryOwner(this@IslandWindowManager)

            setContent {
                val state by IslandStateManager.instance.islandState.collectAsState()

                DynamicIslandTheme {
                    DynamicIslandOverlay(
                        state = state,
                        onTap = {
                            if (state.displayMode == IslandDisplayMode.COMPACT) {
                                IslandStateManager.instance.expandToInteractive()
                            } else {
                                IslandStateManager.instance.collapseToCompact()
                            }
                        },
                        onLongPress = {
                            IslandStateManager.instance.expandToInteractive()
                        },
                        onSwipeUp = {
                            IslandStateManager.instance.collapseToCompact()
                        },
                        onSwipeHorizontal = {
                            IslandStateManager.instance.switchNextActivity()
                        },
                        onDismissActivity = {
                            IslandStateManager.instance.dismissCurrentActivity()
                        },
                        onMusicPlayPause = {
                            mediaHelper.playPause()
                        },
                        onMusicSkipNext = {
                            mediaHelper.skipToNext()
                        },
                        onMusicSkipPrevious = {
                            mediaHelper.skipToPrevious()
                        }
                    )
                }
            }
        }

        try {
            windowManager.addView(composeView, params)
            overlayComposeView = composeView
            isOverlayAttached = true

            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_START)
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_RESUME)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun hideOverlay() {
        if (!isOverlayAttached) return

        try {
            overlayComposeView?.let { windowManager.removeView(it) }
            overlayComposeView = null
            isOverlayAttached = false

            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_PAUSE)
            lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_STOP)
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    fun destroy() {
        hideOverlay()
        lifecycleRegistry.handleLifecycleEvent(Lifecycle.Event.ON_DESTROY)
        store.clear()
    }
}
