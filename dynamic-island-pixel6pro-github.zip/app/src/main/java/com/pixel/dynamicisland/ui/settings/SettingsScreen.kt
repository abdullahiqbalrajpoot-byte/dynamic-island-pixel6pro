package com.pixel.dynamicisland.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bolt
import androidx.compose.material.icons.filled.CenterFocusStrong
import androidx.compose.material.icons.filled.ChevronRight
import androidx.compose.material.icons.filled.Headphones
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.pixel.dynamicisland.model.IslandActivity
import com.pixel.dynamicisland.model.SettingsState
import com.pixel.dynamicisland.ui.theme.DarkCharcoal
import com.pixel.dynamicisland.ui.theme.PixelCyan
import com.pixel.dynamicisland.ui.theme.PureBlack
import com.pixel.dynamicisland.ui.theme.PureWhite
import com.pixel.dynamicisland.ui.theme.SpotifyGreen
import com.pixel.dynamicisland.ui.theme.SurfaceDark
import com.pixel.dynamicisland.ui.theme.TextSecondary

@Composable
fun SettingsScreen(
    settings: SettingsState,
    onUpdateSettings: (SettingsState) -> Unit,
    onOpenCalibration: () -> Unit,
    onTriggerTestActivity: (IslandActivity) -> Unit
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(PureBlack)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // App Header
        item {
            Column(modifier = Modifier.padding(top = 16.dp, bottom = 8.dp)) {
                Text(
                    text = "Dynamic Island",
                    color = PureWhite,
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "Google Pixel 6 Pro Companion",
                    color = TextSecondary,
                    fontSize = 13.sp
                )
            }
        }

        // Master Switch
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column {
                        Text(
                            text = "Enable Dynamic Island",
                            color = PureWhite,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = if (settings.isIslandEnabled) "Floating around front camera" else "Service stopped",
                            color = if (settings.isIslandEnabled) SpotifyGreen else TextSecondary,
                            fontSize = 12.sp
                        )
                    }

                    Switch(
                        checked = settings.isIslandEnabled,
                        onCheckedChange = { onUpdateSettings(settings.copy(isIslandEnabled = it)) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = PureBlack,
                            checkedTrackColor = PixelCyan
                        )
                    )
                }
            }
        }

        // Camera Calibration Shortcut
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = SurfaceDark),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.clickable { onOpenCalibration() }
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .background(PixelCyan.copy(alpha = 0.15f), shape = CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.CenterFocusStrong,
                                contentDescription = null,
                                tint = PixelCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column {
                            Text(
                                text = "Camera Cutout Calibration",
                                color = PureWhite,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "Align pill perfectly with Pixel 6 Pro front lens",
                                color = TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }

                    Icon(
                        imageVector = Icons.Default.ChevronRight,
                        contentDescription = null,
                        tint = TextSecondary
                    )
                }
            }
        }

        // Feature Toggles Section
        item {
            Text(
                text = "FEATURES & INTEGRATIONS",
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 4.dp, top = 8.dp)
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(modifier = Modifier.padding(horizontal = 16.dp)) {
                    FeatureToggleRow(
                        icon = Icons.Default.MusicNote,
                        title = "Music & Spotify Integration",
                        description = "Album art, animated visualizer and playback controls",
                        checked = settings.enableMusicIntegration,
                        onCheckedChange = { onUpdateSettings(settings.copy(enableMusicIntegration = it)) }
                    )

                    FeatureToggleRow(
                        icon = Icons.Default.Notifications,
                        title = "App Notifications",
                        description = "WhatsApp, Instagram, Telegram, Gmail alerts",
                        checked = settings.enableNotifications,
                        onCheckedChange = { onUpdateSettings(settings.copy(enableNotifications = it)) }
                    )

                    FeatureToggleRow(
                        icon = Icons.Default.Bolt,
                        title = "Charging Animation",
                        description = "OLED fast-charging ring and battery percentage",
                        checked = settings.enableChargingAnimation,
                        onCheckedChange = { onUpdateSettings(settings.copy(enableChargingAnimation = it)) }
                    )

                    FeatureToggleRow(
                        icon = Icons.Default.VolumeUp,
                        title = "Volume Indicator",
                        description = "Horizontal volume slider on volume key press",
                        checked = settings.enableVolumeIndicator,
                        onCheckedChange = { onUpdateSettings(settings.copy(enableVolumeIndicator = it)) }
                    )

                    FeatureToggleRow(
                        icon = Icons.Default.Headphones,
                        title = "Bluetooth Device Alerts",
                        description = "Headphones connect / disconnect notifications",
                        checked = settings.enableBluetoothAlerts,
                        onCheckedChange = { onUpdateSettings(settings.copy(enableBluetoothAlerts = it)) }
                    )

                    FeatureToggleRow(
                        icon = Icons.Default.Timer,
                        title = "Timers & Stopwatch",
                        description = "Live background timer countdowns",
                        checked = settings.enableTimers,
                        onCheckedChange = { onUpdateSettings(settings.copy(enableTimers = it)) },
                        isLast = true
                    )
                }
            }
        }

        // Test Activities Simulator
        item {
            Text(
                text = "TEST SIMULATION",
                color = TextSecondary,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                modifier = Modifier.padding(start = 4.dp, top = 8.dp)
            )
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = DarkCharcoal),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Preview Island Activities",
                        color = PureWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Trigger real-time Dynamic Island events on your screen",
                        color = TextSecondary,
                        fontSize = 11.sp
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                onTriggerTestActivity(
                                    IslandActivity.Media(
                                        title = "Starboy",
                                        artist = "The Weeknd, Daft Punk",
                                        album = "Starboy",
                                        durationMs = 230000,
                                        currentPositionMs = 64000,
                                        isPlaying = true,
                                        appName = "Spotify"
                                    )
                                )
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceDark),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Spotify", color = SpotifyGreen, fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                onTriggerTestActivity(
                                    IslandActivity.AppNotification(
                                        id = "test_whatsapp",
                                        packageName = "com.whatsapp",
                                        appName = "WhatsApp",
                                        title = "Alex Turner",
                                        text = "Are you joining the studio session tonight?"
                                    )
                                )
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceDark),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Notification", color = PixelCyan, fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                onTriggerTestActivity(
                                    IslandActivity.Charging(batteryLevel = 92, isFastCharging = true)
                                )
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = SurfaceDark),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("Charging", color = Color(0xFFFFD600), fontSize = 12.sp)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun FeatureToggleRow(
    icon: ImageVector,
    title: String,
    description: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    isLast: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Row(
            modifier = Modifier.weight(1f),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = if (checked) PixelCyan else TextSecondary,
                modifier = Modifier.size(20.dp)
            )

            Spacer(modifier = Modifier.width(12.dp))

            Column {
                Text(
                    text = title,
                    color = PureWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Medium
                )
                Text(
                    text = description,
                    color = TextSecondary,
                    fontSize = 11.sp
                )
            }
        }

        Switch(
            checked = checked,
            onCheckedChange = onCheckedChange,
            colors = SwitchDefaults.colors(
                checkedThumbColor = PureBlack,
                checkedTrackColor = PixelCyan
            )
        )
    }
}
