package com.pixel.dynamicisland.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.lifecycle.LifecycleService
import androidx.lifecycle.lifecycleScope
import com.pixel.dynamicisland.MainActivity
import com.pixel.dynamicisland.R
import com.pixel.dynamicisland.manager.IslandStateManager
import com.pixel.dynamicisland.manager.IslandWindowManager
import com.pixel.dynamicisland.manager.PermissionManager
import com.pixel.dynamicisland.manager.SettingsRepository
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class DynamicIslandOverlayService : LifecycleService() {

    private lateinit var windowManager: IslandWindowManager
    private lateinit var settingsRepo: SettingsRepository

    override fun onCreate() {
        super.onCreate()
        settingsRepo = SettingsRepository.getInstance(this)
        windowManager = IslandWindowManager(this)

        startForegroundNotification()

        // Sync settings into IslandStateManager
        lifecycleScope.launch {
            settingsRepo.settings.collectLatest { settings ->
                IslandStateManager.instance.setIslandEnabled(settings.isIslandEnabled)
                IslandStateManager.instance.updateCutoutOffsets(
                    settings.cameraCutoutXOffset,
                    settings.cameraCutoutYOffset
                )
                IslandStateManager.instance.updatePillDimensions(
                    settings.pillBaseWidthDp,
                    settings.pillBaseHeightDp
                )
            }
        }

        // Show overlay if permission is granted
        if (PermissionManager.hasOverlayPermission(this)) {
            windowManager.showOverlay()
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        super.onStartCommand(intent, flags, startId)
        if (PermissionManager.hasOverlayPermission(this)) {
            windowManager.showOverlay()
        }
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        windowManager.destroy()
    }

    private fun startForegroundNotification() {
        val channelId = "dynamic_island_foreground"
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                getString(R.string.service_notification_channel),
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = getString(R.string.service_notification_content)
                setShowBadge(false)
            }
            notificationManager.createNotificationChannel(channel)
        }

        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            openAppIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val notification: Notification = NotificationCompat.Builder(this, channelId)
            .setContentTitle("Dynamic Island Active")
            .setContentText("Monitoring Pixel 6 Pro punch-hole cutout events")
            .setSmallIcon(R.drawable.ic_island_logo)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .build()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            startForeground(
                NOTIFICATION_ID,
                notification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE
            )
        } else {
            startForeground(NOTIFICATION_ID, notification)
        }
    }

    companion object {
        private const val NOTIFICATION_ID = 1001

        fun start(context: Context) {
            val intent = Intent(context, DynamicIslandOverlayService::class.java)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
        }

        fun stop(context: Context) {
            val intent = Intent(context, DynamicIslandOverlayService::class.java)
            context.stopService(intent)
        }
    }
}
