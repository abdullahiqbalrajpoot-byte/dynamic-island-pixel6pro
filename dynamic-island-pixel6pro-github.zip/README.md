# Dynamic Island for Google Pixel 6 Pro

A native, high-performance Android Dynamic Island application specifically architected for the **Google Pixel 6 Pro** (centre punch-hole front camera).

### 🚀 Key Features Built:
1. **Pixel 6 Pro Hardware Punch-Hole Calibration:**
   - Positioned around the top-center front camera cutout.
   - Built-in live visual calibration tool with X/Y offsets, base pill width, and height sliders.
2. **Floating WindowManager Overlay Engine:**
   - Runs via `TYPE_APPLICATION_OVERLAY` with `FLAG_LAYOUT_NO_LIMITS` and `LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS`.
   - Floats across all applications, home screen, and lock screen.
3. **Spotify & Media Player Integration (Zero Login Required):**
   - Automatically binds to active Android media sessions (`Spotify`, `YouTube Music`, `Apple Music`, `SoundCloud`, etc.).
   - Live album art, track title, artist, seekable progress bar, real-time waveform visualizer, and previous/play/pause/next transport controls.
4. **Live Notifications:**
   - Real-time heads-up notification cards with app icons for WhatsApp, Instagram, Telegram, Messenger, Gmail, etc.
   - Smooth expansion with automatic timeout collapse.
5. **System Events & Hardware Indicators:**
   - **OLED Fast Charging Animation:** Glowing amber ring and battery percentage.
   - **Interactive Volume Bar:** Real-time volume slider on volume key events.
   - **Bluetooth Device Alerts:** Headphones connection status.
   - **Incoming & Active Calls:** Caller avatar, ongoing call timer, answer/decline controls.
   - **Timers & Stopwatch:** Live countdown display with pause/reset.
6. **Fluid Spring Physics Animations:**
   - Jetpack Compose spring-based physics (`Spring.DampingRatioMediumBouncy`, `Spring.StiffnessMediumLow`) for liquid-smooth expansion and contraction.
   - Deep pure OLED black `#000000` with rounded edges.
